#!/usr/bin/python

# Licensed under the MIT license:
# http://www.opensource.org/licenses/mit-license
# Copyright (c) 2021 www.hfm-weimar.de  Hochschule für Musik FRANZ LISZT Weimar

__author__ = "Christon Nadar"
__copyright__ = "Copyright (c) 2021 www.hfm-weimar.de  Hochschule für Musik FRANZ LISZT Weimar"
__license__ = "Licensed under the MIT license:"
__version__ = "1.0"